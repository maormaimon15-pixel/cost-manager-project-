const dns = require('dns');
// הפקודה הזו מכריחה את Node.js לעקוף את הראוטר/ווינדוס ולפנות ישירות לגוגל:
dns.setServers(['8.8.8.8', '1.1.1.1']); 

const mongoose = require('mongoose');
const uri = "mongodb+srv://maormaimon15_db_user:HIRDXyyA85ybDnq8@cluster0.gk9ehgf.mongodb.net/cost_manager?retryWrites=true&w=majority&tlsAllowInvalidCertificates=true";

console.log("Attempting to connect with forced Google DNS bypass...");
mongoose.connect(uri)
  .then(() => console.log("✅ SUCCESS! Connected to MongoDB!"))
  .catch(err => console.log("❌ FAILED:", err.message));